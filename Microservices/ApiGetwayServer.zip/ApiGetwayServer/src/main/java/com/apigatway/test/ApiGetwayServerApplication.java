package com.apigatway.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiGetwayServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiGetwayServerApplication.class, args);
	}

}
